# Common Path: (Not Going to Focus This)

## Programming

![Untitled](Untitled.png)

## Internet

![Untitled](Untitled%201.png)

## Framework

![Untitled](Untitled%202.png)

## Database

![Untitled](Untitled%203.png)

## Git

![Untitled](Untitled%204.png)

## API Design

![Untitled](Untitled%205.png)

## Integration

![Untitled](Untitled%206.png)

## Cloud

![Untitled](Untitled%207.png)